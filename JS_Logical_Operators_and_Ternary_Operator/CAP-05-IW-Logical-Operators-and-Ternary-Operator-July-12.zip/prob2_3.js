// Problem 2 : Given any character, if it is a vowel print "Vowel"

// Problem 3 : Given and character if it is a consonant print "Consonant"

let x = "a";

x == "a" || x == "e" || x == "i" || x == "o" || x == "u" ? console.log("Vowel") : console.log("Consonant")