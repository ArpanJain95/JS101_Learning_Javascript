// Problem 4: Given 3 numbers (all different values), print which is greatest

let a = 25;
let b = 35;
let c = 45;

a > b && a > c ? console.log("a is the greatest") : b > a && b > c ? console.log("b is the greatest") : console.log("c is the greatest")