// Problem 1: If the number is divisible by 3, print a "multiple of 3".

let number = 10;

if(number % 3 == 0)
{
console.log("multiple of 3")
}
else
{
  console.log("not a multiple of 3")
}