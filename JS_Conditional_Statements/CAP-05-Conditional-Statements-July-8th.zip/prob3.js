// Problem 3: Given 2 numbers a and b print which is greater or "both equal".

let a = 23
let b = 95

if (a>b)
{console.log("a is greater than b")}

else if (b>a)
{console.log("b is greater than a")}

else
{console.log("both equal")}