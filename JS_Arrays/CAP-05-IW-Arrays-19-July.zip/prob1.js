// Problem 1 : Given an array print the position (starting with 1) and the element in a single line.

let n = [1, 2, 3, 4, 5];

for(i = 0; i < n.length; i++){
  console.log(n[i]);
}