// Problem 2 : Given a character in lower case print the upper case character

let c = ["character"];

console.log(c[0].toUpperCase());