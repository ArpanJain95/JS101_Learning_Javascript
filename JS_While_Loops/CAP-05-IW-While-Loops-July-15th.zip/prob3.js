// Problem 3: Print the sum of all the multiples of 3 from 0 to the given limit

let start = 0;
let end = 10;
let i=0;

while(start<=end)
  {
    if(start%3==0)
    {
      i = i+start
    }
    start++
  }
console.log(i)