// Problem 2: Print the odd numbers from 0 till the given limit

let start = 1;
let limit = 100;

while(start <= limit)
  {
    console.log(start)
    start++
    start++
  }