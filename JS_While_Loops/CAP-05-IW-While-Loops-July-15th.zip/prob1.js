// Problem 1: Print the numbers from the given starting point till ending point (including both start and end)

let start = 1;
let end = 100;

while(start <= end)
  {
    console.log(start)
    start++
  }